SLI Open Source Cubesat Backplane 12/10/21

Fits inside a 1.5U Cubesat Chassis. It fits 8 PC104 Cards with SLI's PC104 Adapter Card. This will mount directly to SLI's Cubesat Chassis.

Made in KiCad Version 5.1.10
Editing with KiCad requires the built in libraries for the passives.
All other parts are included in the project library.

For Licensing information, see License.txt